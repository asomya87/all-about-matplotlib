#!/usr/bin/env python
# coding: utf-8

# # Drawing pie chart for favorite movie

# In[27]:


import matplotlib.pyplot as plt


#giving two parameters
x=[5,20,20,25,30] #the total is 100
y=['Drama', 'Comedy', 'SciFi', 'Action', 'Romance']
ex=[0.3,0.0,0.0,0.0,0.0]
c=['r','g', 'b', 'y', 'orange']

plt.pie(x, labels=y, explode=ex, colors=c,autopct="%0.2f%%", shadow=True, radius=1, labeldistance=0.8, startangle = 180, textprops={'fontsize':15}, counterclock=False, wedgeprops={'linewidth':4, 'edgecolor':'m'}, rotatelabels=True)

plt.title('Movie pie chart')
plt.legend(loc=2)
plt.show()


# In[28]:


import matplotlib.pyplot as plt


#giving two parameters
x=[5,20,20,25,30] #the total is 100
x1=[40,30,20,10,5]
y=['Drama', 'Comedy', 'SciFi', 'Action', 'Romance']

c=['r','g', 'b', 'y', 'orange']

plt.pie(x, labels=y, radius=1.5)
plt.pie([1], colors='w')

plt.show()


# In[ ]:




