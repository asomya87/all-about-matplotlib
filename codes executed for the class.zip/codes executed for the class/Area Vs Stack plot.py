#!/usr/bin/env python
# coding: utf-8

# # Area Vs Stack plot

# In[1]:


import matplotlib.pyplot as plt

x=[1,2,3,4,5]
area=[1,2,3,4,5]

plt.stackplot(x,area)

plt.show()


# In[13]:


import matplotlib.pyplot as plt

x=[1,2,3,4,5]
area1=[2,3,2,5,4]
area2=[2,3,4,5,6]
area3=[1,3,2,5,4]
l=["area1", "area2", "area3"]

plt.stackplot(x, area1, area2, area3, labels=l, colors=["r", "g", "k"], baseline='zero')

plt.title("Area plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend(loc=2)
plt.grid()

plt.show()


# In[ ]:




