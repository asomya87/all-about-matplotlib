#!/usr/bin/env python
# coding: utf-8

# # Scatter plot using matplotlib

# In[7]:


import matplotlib.pyplot as plt

day=[1, 2, 3, 4, 5, 6, 7]
number=[3, 4, 5, 7, 8, 9, 10]

plt.scatter(day, number, color="r")
plt.title("Scatter plot", fontsize=15)
plt.xlabel("Day", fontsize=15)
plt.ylabel("Number of people", fontsize=15)

plt.show()


# In[25]:


import matplotlib.pyplot as plt

day=[1, 2, 3, 4, 5, 6, 7]
number=[3, 4, 5, 7, 8, 9, 10]
number2=[2,4,6,8,10,12,17]
#colors=[10,20,40,37,67,70,45]
sizes=[200,300,400,500,600,700,800]
plt.scatter(day, number, c=colors, s=sizes, cmap="BrBG")
plt.scatter(day, number2, color='r', s=sizes)
t=plt.colorbar()
t.set_label("Colorbar", fontsize=15)

plt.title("Scatter plot", fontsize=15)
plt.xlabel("Day", fontsize=15)
plt.ylabel("Number of people", fontsize=15)

plt.show()


# In[ ]:




