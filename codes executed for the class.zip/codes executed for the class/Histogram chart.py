#!/usr/bin/env python
# coding: utf-8

# # Histogram chart

# In[3]:


import matplotlib.pyplot as plt
import numpy as np #using this to create data array
import random #this will give us random numbers

#generate fifty random numbers between the range 10 to 60
x=np.random.randint(10,60,(50)) 
print(x)


# In[35]:


number=[21, 37, 15, 15, 55, 20, 53, 56, 58, 22, 29, 10, 48, 48, 55, 25, 36, 59, 41, 53, 21, 34, 52, 15, 22, 30, 24, 59, 43, 36, 37, 13, 33, 44, 15, 58, 36, 49, 44, 20, 20, 17, 49, 58, 17, 53, 29, 56, 49, 21] #separated the data using commas

plt.hist(number, color='g', edgecolor='k', log=True, label='levels')
plt.title("Histogram chart")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.axvline(45,color='r', label='line')
plt.legend(loc=2)

plt.show()


# In[ ]:




