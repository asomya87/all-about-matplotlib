#!/usr/bin/env python
# coding: utf-8

# # Box whisker plot

# In[30]:


import matplotlib.pyplot as plt

x = [10, 20, 30, 40, 50, 60, 70, 120]
x1= [10, 20, 30, 40, 50, 60, 70, 90]

y=[x,x1]

#joining the whisker plot and changing the notation

plt.boxplot(y,  labels=['Python', 'C++'], sym='g+', boxprops=dict(color='r'), capprops=dict(color='b'), whiskerprops=dict(color='r'))

plt.show()


# In[ ]:




