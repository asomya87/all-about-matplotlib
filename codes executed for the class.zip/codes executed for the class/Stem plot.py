#!/usr/bin/env python
# coding: utf-8

# # Stem plot

# In[18]:


import matplotlib.pyplot as plt

x=[1, 2, 3, 4, 5, 6, 7]
y=[3, 4, 5, 7, 4, 9, 3]

plt.stem(x,y, linefmt=":", markerfmt="ro", bottom=6, basefmt='g', label="Python", orientation='horizontal')
plt.legend()

plt.show()


# In[ ]:





# In[ ]:




