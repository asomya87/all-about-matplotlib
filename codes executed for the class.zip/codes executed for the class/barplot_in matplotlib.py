#!/usr/bin/env python
# coding: utf-8

# In[39]:


import matplotlib.pyplot as plt #here pyplot is a class

#giving x parameter and their values

x =["Python", "C", "C++", "Java", "JavaScript"]

#giving y parameter which explains the popularity of these languages

y = [88, 70, 60, 82, 85]
z = [50, 60, 40, 20, 30]
plt.xlabel("Programming languages", fontsize = 15)
plt.ylabel("Popularity percentage", fontsize = 15)
plt.title("Populatory of programming languages", fontsize = 15)
c=['g']
c1=['y']

#plotting the graph

plt.bar(x,y, width=0.4, color =c, label='popularity')
plt.bar(x,z, width=0.4, color =c1, label='popularity1')
plt.legend()
plt.show()


# In[47]:


import matplotlib.pyplot as plt #here pyplot is a class
import numpy as np #used for creating arrays

#giving x parameter and their values
x =["Python", "C", "C++", "Java", "JavaScript"]

#giving y parameter which explains the popularity of these languages
y = [88, 70, 60, 82, 85]
z = [50, 60, 40, 20, 30]

width = 0.2
p=np.arange(len(x)) #this will create an array of length of x which we can use 
p1= [j+width for j in p]


plt.xlabel("Programming languages", fontsize = 15)
plt.ylabel("Popularity percentage", fontsize = 15)
plt.title("Populatory of programming languages", fontsize = 15)


#plotting the graph

plt.bar(p,y, width, color ='g', label='popularity')
plt.bar(p1,z, width, color ='y', label='popularity1')

plt.xticks(p+width/2, x, rotation=15)
plt.legend()
plt.show()


# In[51]:


import matplotlib.pyplot as plt #here pyplot is a class

#giving x parameter and their values

x =["Python", "C", "C++", "Java", "JavaScript"]

#giving y parameter which explains the popularity of these languages

y = [88, 70, 60, 82, 85]
z = [50, 60, 40, 20, 30]

plt.xlabel("Programming languages", fontsize = 15)
plt.ylabel("Popularity percentage", fontsize = 15)
plt.title("Populatory of programming languages", fontsize = 15)

#plotting the graph

plt.barh(x,y, color ='g', label='popularity')
plt.barh(x,z, color ='y', label='popularity1')

plt.legend()
plt.show()


# In[ ]:




