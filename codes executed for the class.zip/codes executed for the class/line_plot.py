#!/usr/bin/env python
# coding: utf-8

# # first_class

# In[1]:


get_ipython().system('pip install matplotlib')


# In[7]:


import matplotlib.pyplot as plt

xpt=[1, 2, 3, 4]
ypt=[2, 3, 4, 6]
plt.plot(xpt,ypt)


# In[ ]:




