#!/usr/bin/env python
# coding: utf-8

# # Step plot

# In[9]:


import matplotlib.pyplot as plt

x = [1,2,3,4,5]
y = [3,4,5,1,3]

plt.step(x,y, color='r', marker='o', ms=10, mfc='g', label='stocks')

plt.title("Step plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

plt.grid()
plt.legend(loc=2)
plt.show()


# 
