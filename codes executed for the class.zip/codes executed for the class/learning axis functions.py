#!/usr/bin/env python
# coding: utf-8

# # learn axis functions

# In[25]:


#let's make a graph first

import matplotlib.pyplot as plt

#x = [1,2,3,4]
#y = [3,1,4,2]

plt.plot(x,y)

plt.xticks(x, labels = ['Python', 'C', 'C++', 'JavaScript'])
plt.ylabel('Popularity of Prog. languages')

plt.axis([0,10,0,6])

plt.show()


# In[ ]:




