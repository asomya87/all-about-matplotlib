#!/usr/bin/env python
# coding: utf-8

# # Savefig

# In[6]:


import matplotlib.pyplot as plt

xpt=[1, 2, 3, 4, 5]
ypt=[2, 4, 3, 6, 4]

plt.plot(xpt,ypt, color='r')

plt.savefig("Line plot-graph", dpi=2000, facecolor='green', transparent=False, bbox_inches='tight')

plt.show()


# In[ ]:





# In[ ]:




